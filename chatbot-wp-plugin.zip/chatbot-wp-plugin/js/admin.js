jQuery(document).ready(function($) {
    $('#upload_custom_icon_button').on('click', function(e) {
        e.preventDefault();

        var uploader = wp.media({
            title: 'Select Custom Launcher Icon',
            button: { text: 'Use this image' },
            multiple: false,
            library: { type: ['image'] }
        }).on('select', function() {
            var attachment = uploader.state().get('selection').first().toJSON();
            $('#chatwootCustomLauncherIcon').val(attachment.url);
        }).open();
    });
});